<?php  
/*** 
 TsMsg::init()->T('juli',array("juli"=>10));
 $title = TsMsg::init()->L('平台派单');
 $content = TsMsg::init()->T('Qs_dishapp58',array('dno'=>$orderinfo['dno']));
**/
class TsMsg
{  
	private static $_instance; 
	private  $staticlang;
	private  $dolang;
    public function __construct()
    {    
		$staticlang = array(
			'转单成功'=>'Chuyển đơn thành công',
			'转派成功'=>'Chuyển giao thành công',
			'待取件订单已被转派成功'=>'Để được chọn đã được chuyển giao thành công',
			'转派失败'=>'Chuyển giao thất bại',
			"转单失败"=>'Chuyển đơn thất bại',
			"转单求助"=>'Yêu cầu chuyển đơn',
			"骑手向您申请转单求助，请及时处理"=>'Người giao hàng đã gửi yêu cầu chuyển đơn, vui lòng xử lý kịp thời',
			"新订单"=>'Đơn hàng mới',
			'来新订单了，快来抢单吧'=>'Bạn có đơn hàng mới, mau nhận đơn.',
			'订单退款中'=>'Đơn hàng đang hoàn tiền',
			'退款取消'=>'Hủy hoàn tiền',
			'同意退款'=>'Đồng ý hoàn tiền',
			"订单已完成"=>"Để hoàn thành",
			"订单已被平台强制完成，点击查看详情"=>'Trật tự đã được buộc phải hoàn thành bởi những nền tảng, nhấn cho chi tiết',
			"平台派单"=>"Hệ thống xếp đơn",
			"待取件"=>"Để được chọn", 
			"订单转派中"=>'Đơn hàng đang chuyển giao',
			"待取件订单正在被转派"=>'Để có thể được nhặt được chuyển',
			"订单已重置"=>'Đặt lại đơn hàng',
			"账号停用"=>'Tài khoản bị khóa',
			"您的账号已被配送站停用"=>'Tài khoản của bạn đã bị vô hiệu hoá',
			"认证成功"=>"Xác thực thành công",
			"认证失败"=>"Xác thực thất bại",
			"您的身份认证已通过，快去运单吧"=>"Xác thực danh tính thành công, bạn có thể tiến hành giao đơn hàng",
			"您的身份认证未通过，点击查看失败详情"=>'Xác thực danh tính không thành công, nhấp để xem lý do thất bại',
		);
		$dolang = array(
			//你申请的单号为1234567890的订单转单成功了
			'Qs_disapp36'=>'Đơn hàng ${dno} chuyển đơn thành công',
			//你申请的单号为${dno}的订单已被配送站接受并调度成功
			'Qs_dishapp54'=>'Đơn hàng có số đơn ${dno} mà bạn đã xin đã được trạm giao hàng nhận và điều phối thành công',
			//单号为1234567890的订单已被平台转派成功
			'Qs_octxt2'=>'Đơn hàng ${dno} chuyển giao thành công',
			//你申请的单号为${dno}的订单平台转派失败
			'Qs_clkapp6'=>'Đơn hàng có số đơn ${dno} mà bạn đã xin, việc chuyển phát của платформа thất bại',
			//你申请的单号为${dno}的订单已被骑手接单
			"Qs_disapp61"=>'Đơn hàng có số đơn ${dno} mà bạn đã xin đã được người giao hàng nhận đơn',
			//你申请的单号为${dno}的订单已被配送站接收并调度成功
			"Qs_disapp60"=>'Đơn hàng có số đơn ${dno} mà bạn đã xin đã được trạm giao hàng nhận và điều phối thành công',
			//你申请的单号为${dno}的订单转单失败了
			"Qs_dishapp58"=>'Đơn hàng ${dno} chuyển đơn thất bại',
			//你申请的单号为${dno}的订单已被骑手拒绝，请继续完成配送
			"Qs_dishapp62"=>'Đơn hàng có số đơn ${dno} mà bạn đã xin đã bị người giao hàng từ chối, Vui lòng tiếp tục hoàn thành việc giao hàng',
			//骑手向您申请转单求助，请及时处理，单号${dno}，若${lmtime_zhuan}秒内未处理自动拒单
			"Qs_dishapp78"=>'Người giao hàng xin bạn giúp chuyển đơn, Vui lòng xử lý kịp thời, Số đơn ${dno}',
			//骑手向您申请转单求助，请及时处理，单号${dno}
			"Qs_dishapp79"=>'Đơn hàng có số đơn ${dno} liên quan đến việc hoàn tiền',
			//单号为1234567890的订单正在退款，请联系商家确认
			"Os_OrderRefund"=>'Đơn hàng ${dno} đang được hoàn tiền, vui lòng liên hệ người bán hàng để xác nhận',
			//单号为1234567890的订单退款申请已取消
			"Os_OrderRefundcancel"=>'Yêu cầu hoàn tiền của đơn hàng ${dno} đã bị hủy',
			//单号为1234567890的订单商家已同意退款
			"Os_OrderRefundagree"=>'Đơn hàng ${dno} đã được người bán hàng đồng ý hoàn tiền', 
			//平台派给您了1笔订单，系统已为您自动接单，请按时完成配送
			"Qs_Pdanzhong"=>'Hệ thống gửi cho bạn ${num} đơn hàng, hệ thống tự động chấp nhận đơn hàng cho bạn, vui lòng giao hàng đúng giờ',
			//平台派给您了1笔订单，请及时处理
			"Qs_Pdanzhongw"=>'Hệ thống gửi cho bạn ${num} đơn hàng, vui lòng xử lý kịp thời',
			//单号为1234567890的订单正在被平台转派
			"Qs_zhuanpaiing"=>'Đơn hàng ${dno} đang chuyển tới người giao hàng',
			//单号为1234567890的订单已被平台重置
			"Qs_chongzhi"=>'Đơn hàng ${dno} đã được đặt lại',
			
		);
		
		$this->staticlang = $staticlang;
		$this->dolang = $dolang;
    }  
	public static function init(){ 
			if(!(self::$_instance instanceof self)){  
				self::$_instance = new self();  
			} 
			return self::$_instance; 
	} 
     
	public  function L($msg)
    {
		return isset($this->staticlang[$msg])?$this->staticlang[$msg]:$msg;
    }   
	public function T($code,$datas=array()){
		 
		
		$orginArray = array();
		$changeArray = array();
		if(is_array($datas) && count($datas) > 0){
			foreach($datas as $key=>$value){
				$orginArray[] = '/\${'.$key.'\}/s';   
				$changeArray[] = $value; 
			} 
		}  
		$tplcontent = $code;
		if(isset($this->dolang[$code]))
        {
            $tplcontent= $this->dolang[$code];
        }  
		return preg_replace($orginArray,$changeArray,$tplcontent); 
	} 
	
	 
}